<?php
! defined ( 'ACLOUD_PATH' ) && exit ( 'Forbidden' );
class ACloudVerConfigDao {
	
	public function getConfig() {
	
	}
}