<?php
defined('WEKIT_VERSION') or exit(403);
return array(
	'operations' => array('运营', array()), 
	'announce_announce' => array('公告管理', 'announce/announce/*', '', '', 'operations'), 
);