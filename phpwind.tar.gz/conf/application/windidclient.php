<?php
defined('WEKIT_VERSION') or exit(403);
/**
 * 全局产品级应用	配置
*/
return array(
	
	/**=====配置开始于此=====**/
	'web-apps' => array(
		'windidclient' => array(
			'default-module' => 'windidclient',
			'root-path' => 'APPS:windidclient', 
			'modules' => array()
		)
	)
);